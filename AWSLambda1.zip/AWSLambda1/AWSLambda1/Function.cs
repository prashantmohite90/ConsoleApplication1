using System;
using Amazon.S3;
using Amazon.S3.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using System.IO;
using Amazon.S3.Util;
using Amazon.S3.Transfer;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace AWSLambda1
{
    public class Function
    {

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<string> FunctionHandler(S3EventNotification evnt, ILambdaContext context)
        {
            var s3Event = evnt.Records?[0].S3;
            if (s3Event == null)
            {
                return null;
            }

            try
            {
                Console.WriteLine($"Handler: getting object {s3Event.Object.Key} from bucket {s3Event.Bucket.Name}.");

                AmazonS3Client client = new AmazonS3Client("AKIAICC35AR3QGEL3A4A", "yyLbNSo7GmbYVtC346isMhEE6Ap1xW9c6upHUayM", Amazon.RegionEndpoint.USEast1);
                var response = await client.GetObjectAsync(s3Event.Bucket.Name, s3Event.Object.Key);
                
                using (var stream = response.ResponseStream)
                {
                    var memStream = new MemoryStream();
                    stream.CopyTo(memStream);
                    TextReader tr = new StreamReader(stream);
                    Console.WriteLine("File Contains");
                    Console.WriteLine(tr.ReadToEnd());
 
                    using (var transferUtility = new TransferUtility(client))
                    {

                        var request = new TransferUtilityUploadRequest
                        {
                            BucketName = "outputfilecontainer",
                            Key = s3Event.Object.Key,
                            InputStream = memStream
                        };
                        Console.WriteLine(" file uploaded to another bucket");
                        transferUtility.Upload(request);
                    }
                    return null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine("Handler: FAILED to process mail successfully");
                throw;
            }
        }
    }
}
