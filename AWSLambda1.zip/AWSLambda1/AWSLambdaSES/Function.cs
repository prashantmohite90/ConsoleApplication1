using System;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.S3.Util;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using Amazon.Runtime;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace AWSLambdaSES
{
    public class Function
    {

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task<string> FunctionHandler(S3EventNotification evnt, ILambdaContext context)
        {
            var s3Event = evnt.Records?[0].S3;
            if (s3Event == null)
            {
                return null;
            }

            try
            {
                Console.WriteLine($"Handler: getting object {s3Event.Object.Key} from bucket {s3Event.Bucket.Name}.");
                AmazonS3Config config = new AmazonS3Config();
                config.SignatureMethod = SigningAlgorithm.HmacSHA256;
                config.SignatureVersion = "4";
                config.RegionEndpoint = Amazon.RegionEndpoint.USEast1;
                AmazonS3Client client = new AmazonS3Client("AKIAICC35AR3QGEL3A4A", "yyLbNSo7GmbYVtC346isMhEE6Ap1xW9c6upHUayM",config);
                var response = await client.GetObjectAsync(s3Event.Bucket.Name, s3Event.Object.Key);
                GetPreSignedUrlRequest request = new GetPreSignedUrlRequest();
                request.BucketName = s3Event.Bucket.Name;
                request.Key = s3Event.Object.Key;
                request.Expires = DateTime.Now.AddMonths(1);
                request.Protocol = Protocol.HTTP;
                var url = client.GetPreSignedURL(request);
                AmazonSimpleEmailServiceClient amzClient = new AmazonSimpleEmailServiceClient("AKIAICC35AR3QGEL3A4A",
                "yyLbNSo7GmbYVtC346isMhEE6Ap1xW9c6upHUayM", Amazon.RegionEndpoint.USEast1);

                //ADD AS TO 50 emails per one sending method/////////////////////
                Destination dest = new Destination();
                dest.ToAddresses.Add("prash.mohite007@gmail.com");

                if(s3Event.Object.Key.Contains("-xp"))
                    dest.ToAddresses.Add("prashantm@xpanxion.co.in");

                dest.ToAddresses.Add("prash.mohite007@gmail.com");
                string body = "Access file at  Location "+url;
                string subject = "S3 File  Location";
                Body bdy = new Body();
                bdy.Html = new Amazon.SimpleEmail.Model.Content(body);
                Amazon.SimpleEmail.Model.Content title = new Amazon.SimpleEmail.Model.Content(subject);
                Message message = new Message(title, bdy);
                SendEmailRequest ser = new SendEmailRequest("prashantadhikraomohite@gmail.com", dest, message);
                SendEmailResponse seResponse = await amzClient.SendEmailAsync(ser);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine("Handler: FAILED to process  successfully");
                throw;
            }
        }
    }
}
